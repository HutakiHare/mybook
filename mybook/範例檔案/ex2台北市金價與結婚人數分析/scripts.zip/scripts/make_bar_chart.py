import pandas as pd
import numpy as np
import plotly.graph_objects as go

# Access the input and output files from Snakemake
input_file = str(snakemake.input[0])
output_file = str(snakemake.output[0])

df = pd.read_csv(input_file)

if 'marriage' in input_file:
    col1 = '結婚對數/總計[對]'
    col2 = '年別'
    layout_title = '台北結婚對數變化圖'
    ytitle = '結婚對數/總計[對]'
    markcolor = 'blue'
elif 'economy' in input_file:
    col1 = '黃金[飾金]市價[元/臺錢]'
    col2 = '年底別'
    layout_title = '台北黃金市價變化圖'
    ytitle = '黃金市價[元/臺錢]'
    markcolor = 'gold'

bar = go.Bar(
    x=df[col2],
    y=df[col1],
    marker=dict(color=markcolor)
)

layout = go.Layout(
    title=layout_title,
    title_font_size = 30,
    xaxis=dict(title="年分"),
    yaxis=dict(title=ytitle)
)

fig = go.Figure(data=bar, layout=layout)
fig.write_html(output_file)
